# StudyAI v0.2 — Android Cloud Build Project

This repository contains a small Android WebView wrapper and an offline-first Arabic study app prototype.

## Features included
- Local courses and lessons
- Lesson completion and progress tracking
- Local notes
- Self-test question/answer cards
- AI curriculum prompt generator (generates a prompt; it does not call an AI service directly)
- JSON backup export/import
- Local browser storage

## Build an APK on GitHub
1. Create a GitHub repository.
2. Upload the **contents of this folder**, not this ZIP file itself.
3. Ensure the default branch is `main` or `master`.
4. Open **Actions** and choose **Build StudyAI APK**.
5. Click **Run workflow** (or push a commit to trigger a build).
6. When the workflow completes, open its run and download the `StudyAI-debug-apk` artifact.

## Important limitations
- This is a buildable starter version, not a signed release APK.
- AI integration is not connected; the AI Lab prepares prompts to copy into an AI service.
- Content is stored locally in the app WebView. Uninstalling or clearing app data may erase it; use JSON export for backup.
- A production release should add testing, accessibility checks, robust storage, and a secure server-side AI integration if desired. Never put private API keys in client-side files.
